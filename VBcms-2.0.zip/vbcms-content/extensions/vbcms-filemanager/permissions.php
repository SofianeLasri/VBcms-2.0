<?php
$permissions = [
    'access-browse'
];