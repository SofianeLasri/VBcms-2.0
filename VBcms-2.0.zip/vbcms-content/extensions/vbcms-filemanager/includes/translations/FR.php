<?php
// Traduction gestionnaire de fichiers

$translation["gallery_filemanager"] = "Gestionnaire de fichiers";
$translation["gallery_medias"] = "Médias";
$translation["sample"] = "sample";
$translation["sample"] = "sample";
$translation["sample"] = "sample";
$translation["sample"] = "sample";