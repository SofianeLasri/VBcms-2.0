# VBcms pre2.1b
Cette version est une simple mise à jour de la version 2.1, dans le but de rendre le cms indépendant du gestionnaire de comptes vbcms.net.

## Comment installer le cms ?
À cette heure-ci (19/09/2021) il n'est pas encore possible d'installer le cms. Je dois recréer le système de mise à jour ainsi que l'installateur. **Reviens plus-tard, tu peux rejoindre mon discord en attendant.**
https://discord.gg/Qbgew8R4Ga
