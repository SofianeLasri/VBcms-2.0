<?php
$permissions = [
    'accessAdmin',
    'viewPermissions',
    'editPermissions',
    'access-generalSettings',
    'manageUsersSettings',
    'manageUserGroupsSettings',
    'permissionsSettings',
    'extAndWsSettings'
];