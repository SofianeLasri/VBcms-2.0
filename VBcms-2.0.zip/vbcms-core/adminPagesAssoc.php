<?php
$adminPagesAssoc = array();
$adminPagesAssoc[""] = ""; //index.php -> je met rien car sinon on a une boucle infinie, même si en théorie on ne devait pas rentrer ici avec ""
$adminPagesAssoc["settings"] = "settings.php";
$adminPagesAssoc["updater"] = "updater.php";
$adminPagesAssoc["test"] = "test.php";
$adminPagesAssoc["404"] = "404.php";
$adminPagesAssoc["debug"] = "debug.php";
$adminPagesAssoc["login"] = "login.php";

$adminPagesAssoc["backTasks"] = "backTasks.php";
$adminPagesAssoc["workshop"] = "ws-handler.php";