<?php
require_once "vbcms-core/core.php";

/*
VBcms redirige toutes ses pages sur cet index,
le fichier header.php se charge d'inclure des pages correspondants aux paramètres de l'url
NE TOUCHEZ PAS À CE FICHIER !
Si vous voulez créer un thème, ça se trouve dans /vbcms-content/themes
*/